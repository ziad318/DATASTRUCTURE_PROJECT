Project dependencies: -
_________________________

Problem 1 : Sections and Deoctors lectures 

Problem 2 : Doctors lecture and youyube channel newBaghdad in data structure 

Problem 3 : Doctors lectures and sections and stack over flow

Problem 4 : Sections and Doctors lectures 

__________________________________________________________________________________

Project Setup: -
__________________________

1. You must extract the zipped file
2. Open the netbeans IDE or anyother IDE
3. Then click on "file" and then on "open file"
4. Then choose the extracted file from the saving distenation
5. Run the project on the used IDE
___________________________________________________________________________________
 
-----
P E  |
-----

Problem 3: 

1. the input is line by line you must click enter on every input because we didnt know how to take the input from the user on one line.
2. the code executes in 60 seconed so waion on the code to run and gived the output.


problem 4:

1. we used the section code we just edited it to fit the required problem sp we couldnt take the input from the user we made the input hard-coded.
